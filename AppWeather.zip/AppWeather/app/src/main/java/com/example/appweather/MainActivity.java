package com.example.appweather;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class MainActivity extends AppCompatActivity {
    TextView tv, tv1, tv2, tv3, tv4, city_logo, day2, day3, day4, day5;
    EditText get_city;
    String city;
    ImageView imageView;
    ConstraintLayout layout;
    WeatherDB database;
    ArrayList<String> cur_db_data = new ArrayList<String>();
    ArrayList<String> fur_db_data = new ArrayList<String>();

    String[] description = new String[4];
    String[] temp = new String[4];
    String[] icon = new String[4];
    String[] data = new String[4];

    FusedLocationProviderClient fusedLocationProviderClient; // создаём объект класса FusedLocationProviderClient для получения данных о нашем местоположении (Внутри класса реализованны API Google Service)
    public static String latitude, longitude;
    private final static int REQUEST_CODE = 100;

    @SuppressLint({"UseCompatLoadingForDrawables", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.out_deg);
        tv1 = findViewById(R.id.out_other);
        tv2 = findViewById(R.id.out_cloudy);
        tv3 = findViewById(R.id.out_windy);
        tv4 = findViewById(R.id.out_pressure);
        get_city = findViewById(R.id.get_city);
        imageView = findViewById(R.id.imageView);
        city_logo = findViewById(R.id.city_logo);
        layout = findViewById(R.id.linearLayout);
        day2 = findViewById(R.id.day2);
        day3 = findViewById(R.id.day3);
        day4 = findViewById(R.id.day4);
        day5 = findViewById(R.id.day5);


        database = new WeatherDB(this);


        get_background(layout);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this); // инициализируем объект класса FusedLocationProviderClient в соответствии с текущим контекстом
        try {
            cur_db_data = database.get_cur_data();
            city_logo.setText(cur_db_data.get(0));
            tv.setText(cur_db_data.get(1) + " °C");
            loadImageFromAsset(cur_db_data.get(2));
            fur_db_data = database.get_fur_data();
            day2.setText(fur_db_data.get(0));
            day3.setText(fur_db_data.get(1));
            day4.setText(fur_db_data.get(2));
            day5.setText(fur_db_data.get(3));
        } catch (IndexOutOfBoundsException e){
            System.out.println("БД пустая");
        }

        getLastLocation(); // Вызываем процедуру для определения текущего местоположения и вывода названия города с прогнозом погоды (Происходит непосредственно сразу после запуска приложения)

        get_city.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    city = get_city.getText().toString().trim(); // Получаем строку со значением города
                    String[] a = {city}; // Форматируем данные под формат процедуры get_weather()
                    get_weather(a); // Вызываем процедуру get_weather(), передавая в качестве аргумента название города, введённое пользователем
                    city_logo.setVisibility(View.VISIBLE); // отображаем textview с названием города
                    get_city.setVisibility(View.INVISIBLE); // скрываем поле для ввода текста
                    clear(v); // очищаем поле для ввода текста
                    return false;
                }
                return false;
            }
        });

    }

    public void loadImageFromAsset(String icon) {
        try {
            // получаем входной поток
            InputStream ims = getAssets().open(icon + ".png");
            // загружаем как Drawable
            Drawable d = Drawable.createFromStream(ims, null);
            // выводим картинку в ImageView
            imageView.setImageDrawable(d);
            imageView.setVisibility(View.VISIBLE);
        }
        catch(IOException ex) {
            return;
        }
    }

    public void clear(View c){
        get_city.setText("");
    }

    public void click_city(View c) { // Процедура, отображающая поле для ввода текста (названия города)
        city_logo.setVisibility(View.INVISIBLE); // скрываем textview с названием города
        get_city.setVisibility(View.VISIBLE); // отображаем поле для ввода текста
        get_city.requestFocus(); // устанавливаем фокус (курсор) на поле для ввода текста
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE); // создаем объект класса InputMethodManager для автоматического отображения клавиатуры после нажатия на textview, инициализируем его актуальным интерфейсом, используемым для ввода данных
        imm.showSoftInput(get_city, InputMethodManager.SHOW_IMPLICIT); // отображаем клавиатуру для ввода текста
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    public void set_back_assets(String state_day) { // Процедура, меняющая фон основного слоя, принимает на вход название изображения из папки assets
        InputStream back = null;
        try {
            back = getAssets().open(state_day + ".jpg");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable background = Drawable.createFromStream(back, null);
        layout.setBackground(background);
    }

    public void get_background(ConstraintLayout layout) { // Процедура, получающая название фоновой картинки в зависимости от текущего времени и вызывающая соответствующую процедуру для установки полученной фоновой картинки

        Calendar cal = Calendar.getInstance();
        int time = Integer.parseInt(String.valueOf(cal.get(Calendar.HOUR_OF_DAY)));
        System.out.println(time);

        if ((time == 23) || ((time >= 0) && (time <6))) {
            String state_day = "night";
            set_back_assets(state_day);
        }

        if ((time >= 6) && (time < 12)) {

            String state_day = "morning";
            set_back_assets(state_day);
        }

        if ((time >= 12) && (time < 18)) {

            String state_day = "day";
            set_back_assets(state_day);
        }

        if ((time >= 18) && (time < 23)) {

            String state_day = "evening";
            set_back_assets(state_day);
        }

    }

    public void get_weather(String[] city_id) { // Процедура, отображающее текущее погодное состояние по названию города или по координатам lat, lon
        String userAPI = "c341e34f9b7c327502cde34aa7817c5f"; // API OpenWeatherMap
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext()); // Создаём объект класса RequestQueue, для последующего формирования запроса
        DecimalFormat df = new DecimalFormat("#.##");
        String url, url2;

        if (city_id.length == 1) {
            url = "https://api.openweathermap.org/data/2.5/weather?q=" + city_id[0] + "&units=metric&lang=ru&appid=" + userAPI;
            url2 = "https://api.openweathermap.org/data/2.5/forecast?q=" + city_id[0] + "&units=metric&lang=ru&appid=" + userAPI;
        } else {
            url = "https://api.openweathermap.org/data/2.5/weather?lat=" + city_id[0] + "&lon=" + city_id[1] + "&units=metric&lang=ru&appid=" + userAPI;
            url2 = "https://api.openweathermap.org/data/2.5/forecast?lat=" + city_id[0] + "&lon=" + city_id[1] + "&units=metric&lang=ru&appid=" + userAPI;

        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url,null, new Response.Listener<JSONObject>()
        {
            @Override
            public void onResponse(JSONObject response) {
                String output = "";

                try {

                    JSONObject jsonResponse = new JSONObject(String.valueOf(response));
                    JSONArray jsonArray = jsonResponse.getJSONArray("weather");
                    JSONObject jsonObjectWeather = jsonArray.getJSONObject(0);
                    String description = jsonObjectWeather.getString("description");
                    JSONObject main = jsonResponse.getJSONObject("main");

                    JSONArray coord = (JSONArray) response.get("weather");
                    JSONObject sec = (JSONObject) coord.get(0);
                    String icon = sec.getString("icon");
                    loadImageFromAsset(icon);

                    String city_name = response.getString("name"); // Получаем название города из OpenWeatherMap
                    city_logo.setText(city_name); // Устанавливаем название города в TextView
                    String s = main.getString("temp");
                    double temp = main.getDouble("temp");
                    int i = (int)Float.parseFloat(s.trim());
                    s = String.valueOf(i);
                    tv.setText(s + "°C");

                    double feelsLike = main.getDouble("feels_like");

                    float pressure = main.getInt("pressure");
                    tv4.setText(pressure + " гПа");

                    int humidity = main.getInt("humidity");

                    JSONObject jsonObjectWind = jsonResponse.getJSONObject("wind");
                    String wind = jsonObjectWind.getString("speed");
                    tv3.setText(wind + "м/с");

                    JSONObject jsonObjectClouds = jsonResponse.getJSONObject("clouds");
                    String clouds = jsonObjectClouds.getString("all");
                    tv2.setText(clouds + "%");

                    JSONObject jsonObjectSys = jsonResponse.getJSONObject("sys");

                    output += "Чувствуется как: " + df.format(feelsLike) + " °C"
                            + "\nВлажность: " + humidity + "%"
                            + "\nОписание: " + description;
                    tv1.setText(output);
                    database.insertData(city_name,s,icon);
                    System.out.println(database.get_cur_data().get(0));


                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(),"Ошибка1!",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(),"Нет интернета",Toast.LENGTH_SHORT).show();
                    }
                });
        JsonObjectRequest request_all = new JsonObjectRequest(Request.Method.GET, url2,null, new Response.Listener<JSONObject>()
        {
            @Override
            public void onResponse(JSONObject response) {
                String output1,output2,output3,output4;

                try {

                    JSONObject jsonResponse = new JSONObject(String.valueOf(response));
                    JSONArray jsonArray = jsonResponse.getJSONArray("list");
                    String city_name = jsonResponse.getJSONObject("city").getString("name");
                    String[] data = new String[4];
                    String[] description = new String[4];
                    String[] icon = new String[4];
                    double[] temp = new double[4];
                    double[] pressure = new double[4];
                    for(int i = 8; i < 33; i += 8) {
                        JSONObject jsonObjectDay = jsonArray.getJSONObject(i);
                        data[(i/8)-1] = jsonObjectDay.getString("dt_txt");
                        description[(i/8)-1] = jsonObjectDay.getJSONArray("weather").getJSONObject(0).getString("description");
                        icon[(i/8)-1] = jsonObjectDay.getJSONArray("weather").getJSONObject(0).getString("icon");
                        temp[(i/8)-1] = jsonObjectDay.getJSONObject("main").getDouble("temp");
                        pressure[(i/8)-1] = jsonObjectDay.getJSONObject("main").getDouble("pressure");

                    }
                    output1 = "  Дата: " + data[0] + "\n  " + description[0] + "\n  " + df.format(temp[0]) + " °C ," + " давление " + pressure[0] + " гПа";
                    output2 = "  Дата: " + data[1] + "\n  " + description[1] + "\n  " + df.format(temp[1]) + " °C ," + " давление " + pressure[1] + " гПа";
                    output3 = "  Дата: " + data[2] + "\n  " + description[2] + "\n  " + df.format(temp[2]) + " °C ," + " давление " + pressure[2] + " гПа";
                    output4 = "  Дата: " + data[3] + "\n  " + description[3] + "\n  " + df.format(temp[3]) + " °C ," + " давление " + pressure[3] + " гПа";
                    day2.setText(output1);
                    day3.setText(output2);
                    day4.setText(output3);
                    day5.setText(output4);
                    database.insertDataFuture(output1,output2,output3,output4);
                    System.out.println(database.get_fur_data());


                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(),"Ошибка2!",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),"Нет интернета",Toast.LENGTH_SHORT).show();
                    }
                });

        queue.add(request);
        queue.add(request_all);
    }
    private void getLastLocation() { // Получаем координаты текущего местоположения, используя fusedLocationProviderClient

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            //fusedLocationProviderClient.getLastLocation()
            fusedLocationProviderClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cancellationTokenSource.getToken())
                    .addOnSuccessListener(new OnSuccessListener<Location>() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onSuccess(Location location) {
                            if (location !=null){
                                latitude = String.valueOf(location.getLatitude()); // Извлекаем широту
                                longitude = String.valueOf(location.getLongitude()); // Извлекаем долготу
                                String[] city_id = {latitude, longitude}; // Упаковываем эти данные в массив
                                get_weather(city_id); // Вызываем процедуру для получения погоды по данным сервисов геолокации
                            }
                        }
                    });

        }else
        {

            askPermission();

        }
    }

    private void askPermission() { // Запрос прав доступа к сервисам геолокации
        ActivityCompat.requestPermissions(MainActivity.this, new String[]
                {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
    }

    @Override // Проверка прав доступа к сервисам геолокации
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            } else {
                Toast.makeText(this, "Требуется разрешение на геопозицию", Toast.LENGTH_SHORT).show();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}

