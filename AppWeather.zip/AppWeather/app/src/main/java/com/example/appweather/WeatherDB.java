package com.example.appweather;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class WeatherDB extends SQLiteOpenHelper {

    private static final String db_name = "WeatherDB";
    private static final int db_ver = 1;
    private static final String db_table_1 = "current_weather";
    private static final String column_cur_city = "City";
    private static final String column_cur_weather = "Weather";
    private static final String column_cur_icon = "Icon";

    private static final String db_table_2 = "predict_weather";
    private static final String column_fur_city = "City";
    private static final String column_fur_weather = "Weather";
    private static final String column_fur_icon = "Icon";
    private static final String column_fur_data = "Data";

//    База данных: WeatherDB
//    Таблица 1: current_weather
//    Общий вид:
//    ID   City     Weather   Icon
//    1    Moscow    -5       n40


    // Процедура-конструктор базы данных
    public WeatherDB(@Nullable Context context) {
        super(context, db_name, null, db_ver);
    }

    // В теле данного метода onCreate реадизуем sql-запрос для создания таблиц
    //  в уже созданной на предыдущем шаге базе данных
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // В переменной query записан sql-запрос, для создания таблицы с тремя столбцами (структуру таблицы см. выше), для удобства используется форматированная строка (чтобы не писать названия столбцов вручную в строку),
        // %s позиционно соответствуют значения переменных, перечисленных через запятую
        String query = String.format("CREATE TABLE %s (ID INTEGER PRIMARY KEY AUTOINCREMENT, %s TEXT NOT NULL, %s TEXT NOT NULL, %s TEXT NOT NULL);", db_table_1, column_cur_city, column_cur_weather, column_cur_icon);
        String query2 = String.format("CREATE TABLE %s (ID INTEGER PRIMARY KEY AUTOINCREMENT, %s TEXT NOT NULL, %s TEXT NOT NULL, %s TEXT NOT NULL, %s TEXT NOT NULL);", db_table_2, column_fur_city, column_fur_weather, column_fur_icon, column_fur_data);
        sqLiteDatabase.execSQL(query); // выполняем запрос, записанный в query
        sqLiteDatabase.execSQL(query2); // выполняем запрос, записанный в query
    }

    // В теле метода onUpgrade реализуем перезапись значений в базе данных,
    // используя соответствующий sql-запрос для удаления существующей таблицы.
    // Затем, вызываем метод onCreate(), для создания пустой таблицы
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String query = String.format("DELETE TABLE IF EXISTS %s", db_table_1);
        String query2 = String.format("DELETE TABLE IF EXISTS %s", db_table_2);
        sqLiteDatabase.execSQL(query); // выполняем запрос, записанный в query
        sqLiteDatabase.execSQL(query2); // выполняем запрос, записанный в query
        onCreate(sqLiteDatabase); // Создаём пустую таблицу
    }

    public void deleteAll1() // Удаляет все элементы из таблицы
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ db_table_1);
        db.close();
    }

    public void deleteAll2() // Удаляет все элементы из таблицы
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ db_table_2);
        db.close();
    }
    // Реализуем метод для добавления данных в таблицу "current_weather"
    public void insertData(String city, String weather, String icon){
        deleteAll1();
        SQLiteDatabase db = this.getWritableDatabase(); // Создаём абстракцию для записи данных в БД

        ContentValues values = new ContentValues(); // Создаем объекс класса ContentValues для записи значений в таблицу, используя соответствующие методы этого класса
        values.put(column_cur_city, city); // В столбец column_cur_city записывается город, переданный в строковом параметре city,
        // далее по аналогии остальные столбцы заполняется данными
        values.put(column_cur_weather, weather);
        values.put(column_cur_icon, icon);
        // Добавляем заполненные столбцы в таблицу db_table_1
        db.insertWithOnConflict(db_table_1, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    // Реализуем метод для добавления данных в таблицу "predict_weather"
    public void insertDataFuture(String city, String weather, String icon, String data){
        deleteAll2();
        SQLiteDatabase db = this.getWritableDatabase(); // Создаём абстракцию для записи данных в БД

        ContentValues values = new ContentValues(); // Создаем объекс класса ContentValues для записи значений в таблицу, используя соответствующие методы этого класса
        values.put(column_fur_city, city); // В столбец column_cur_city записывается город, переданный в строковом параметре city,
        // далее по аналогии остальные столбцы заполняется данными
        values.put(column_fur_weather, weather);
        values.put(column_fur_icon, icon);
        values.put(column_fur_data, data);
        // Добавляем заполненные столбцы в таблицу db_table_1
        db.insertWithOnConflict(db_table_2, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    // Реализуем метод для получения данных из таблицы "current_weather" в виде строкового динамического массива
    public ArrayList<String> get_cur_data(){
        ArrayList<String> cur_data = new ArrayList<>(); // создаем пустой список (инициализируем параметр cur_data)
        SQLiteDatabase db = this.getReadableDatabase(); // Создаём абстракцию для считывания данных из БД
        // создаём объект класса Cursor - по сути это итератор, считывающий поэлементно данные в таблице, затем эти данные добавляются в строковый массив, параметры выборки и группировки инициализируем как null
        Cursor cursor = db.query(db_table_1, new String[]{column_cur_city, column_cur_weather, column_cur_icon}, null, null, null, null, null);
        while (cursor.moveToNext()){
            // Перебираем значения в таблице и последовательно добавляем их в массив
            int index = cursor.getColumnIndex(column_cur_city);
            cur_data.add(cursor.getString(index));

            int i = cursor.getColumnIndex(column_cur_weather);
            cur_data.add(cursor.getString(i));

            int j = cursor.getColumnIndex(column_cur_icon);
            cur_data.add(cursor.getString(j));

        }
        cursor.close(); // Заканчиваем работу с курсором
        db.close(); // Заканчиваем работу с БД
        return cur_data; // Возвращаем список значений

    }
    // Реализуем метод для получения данных из таблицы "predict_weather" в виде строкового динамического массива
    public ArrayList<String> get_fur_data(){
        ArrayList<String> fur_data = new ArrayList<>(); // создаем пустой список (инициализируем параметр cur_data)
        SQLiteDatabase db = this.getReadableDatabase(); // Создаём абстракцию для считывания данных из БД
        // создаём объект класса Cursor - по сути это итератор, считывающий поэлементно данные в таблице, затем эти данные добавляются в строковый массив, параметры выборки и группировки инициализируем как null
        Cursor cursor = db.query(db_table_2, new String[]{column_fur_city, column_fur_weather, column_fur_icon, column_fur_data}, null, null, null, null, null);
        while (cursor.moveToNext()){
            // Перебираем значения в таблице и последовательно добавляем их в массив
            int index = cursor.getColumnIndex(column_fur_city);
            fur_data.add(cursor.getString(index));

            int i = cursor.getColumnIndex(column_fur_weather);
            fur_data.add(cursor.getString(i));

            int j = cursor.getColumnIndex(column_fur_icon);
            fur_data.add(cursor.getString(j));

            int k = cursor.getColumnIndex(column_fur_data);
            fur_data.add(cursor.getString(k));

        }
        cursor.close(); // Заканчиваем работу с курсором
        db.close(); // Заканчиваем работу с БД
        return fur_data; // Возвращаем список значений

    }
}
