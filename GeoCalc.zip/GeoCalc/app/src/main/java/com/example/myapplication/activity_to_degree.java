package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.net.Uri;
import android.widget.TextView;
import android.widget.Toast;


public class activity_to_degree extends AppCompatActivity {

    TextView textView10;
    EditText editTextNumberDecimal2, editTextNumberDecimal1, editTextNumberDecimal3;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_degree);
        textView10 = findViewById(R.id.tr1);
        editTextNumberDecimal2 = findViewById(R.id.editTextNumberDecimal2);
        editTextNumberDecimal1 = findViewById(R.id.tr2);
        editTextNumberDecimal3 = findViewById(R.id.editTextNumberDecimal3);
        button2 = findViewById(R.id.tr11);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Double d = Double.parseDouble(editTextNumberDecimal2.getText().toString());
                    Double m = Double.parseDouble(editTextNumberDecimal1.getText().toString());
                    Double s = Double.parseDouble(editTextNumberDecimal3.getText().toString());
                    Double u = geo_calc.toDegree(d, m, s);
                    textView10.setText(String.valueOf(u));
                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), "Ошибка", Toast.LENGTH_SHORT).show();
                    ;
                }
            }
        } );
        textView10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_to_degree = textView10.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_to_degree);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"Скопировано", Toast.LENGTH_SHORT).show();
                editTextNumberDecimal2.setText("");
                editTextNumberDecimal1.setText("");
                editTextNumberDecimal3.setText("");
            }
        });
        }
    public void menu(View view)
    {
        Intent menu = new Intent(this, MainActivity.class);
        startActivity(menu);

    }
    public void browser(View view5) {

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.miigaik.ru/"));
        startActivity(browserIntent);
    }
    public void vk(View view6) {

        Intent vkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://vk.com/daria_cross/"));
        startActivity(vkIntent);
    }


}