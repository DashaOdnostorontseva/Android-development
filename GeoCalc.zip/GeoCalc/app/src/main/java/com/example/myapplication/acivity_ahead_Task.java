package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.net.Uri;
import android.widget.TextView;
import android.widget.Toast;

public class acivity_ahead_Task extends AppCompatActivity {

    TextView tr1, at1;
    EditText at2, at3, at4, tr2;
    Button button2, iV1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acivity_ahead_task);
        tr1 = findViewById(R.id.tr1);
        at1 = findViewById(R.id.at1);
        at2 = findViewById(R.id.at2);
        at3 = findViewById(R.id.at3);
        at4 = findViewById(R.id.at4);
        tr2 = findViewById(R.id.tr2);
        button2 = findViewById(R.id.tr11);
        iV1 = findViewById(R.id.iV1);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    Double Xa1 = Double.parseDouble(at2.getText().toString());
                    Double Ya1 = Double.parseDouble(at3.getText().toString());
                    Double D1 = Double.parseDouble(at4.getText().toString());
                    Double degree = Double.parseDouble(tr2.getText().toString());
                    String Xb1Yb1 = geo_calc.AheadTask(Xa1, Ya1, D1, degree);
                    String[] XY = Xb1Yb1.split(" ");
                    tr1.setText(XY[0]);
                    at1.setText(XY[1]);
                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), "Ошибка", Toast.LENGTH_SHORT).show();
                    ;
                }
            }
        } );

        iV1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_inverse_task = "Xb = " + tr1.getText().toString() + " Yb = " + at1.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_inverse_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"Скопированы все данные", Toast.LENGTH_SHORT).show();
                at2.setText("");
                at3.setText("");
                at4.setText("");
                tr2.setText("");
            }
        });

        tr1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_ahed_task = tr1.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_ahed_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"Xb скопировано", Toast.LENGTH_SHORT).show();
                at2.setText("");
                at3.setText("");
                at4.setText("");
                tr2.setText("");
            }
        });
        at1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_ahed_task = at1.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_ahed_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"Yb скопировано", Toast.LENGTH_SHORT).show();
                at2.setText("");
                at3.setText("");
                at4.setText("");
                tr2.setText("");
            }
        });
    }

    public void menu(View view)
    {
        Intent menu = new Intent(this, MainActivity.class);
        startActivity(menu);
    }
    public void browser(View view5) {

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.miigaik.ru/"));
        startActivity(browserIntent);
    }
    public void vk(View view6) {

        Intent vkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://vk.com/daria_cross/"));
        startActivity(vkIntent);
    }
}