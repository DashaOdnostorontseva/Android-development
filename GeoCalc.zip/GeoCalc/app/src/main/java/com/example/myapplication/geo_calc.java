package com.example.myapplication;

public class geo_calc {
    public static void main(String[] args)
    {
        double u = toDegree(217,14,23);
        String result = toRevert(23.9058333333);
        String h = AheadTask(25,140,124,217.2397222222);
        String l = InverseTask(247.32, 870.54, 705.65217, -567.83);
    }

    //Перевод в десятичные градусы
    static double toDegree(double d,double m, double s)
    {
        double u = d+m/60.00 + s/3600.00;
        return u;
    }
    //Перевод в градусы, минуты, секунды
    static String toRevert(double degree)
    {
        double d = (int)degree;
        double m = Math.floor(degree%1*60);
        double s = (degree%1*60)%1*60;
        String result=String.format("%.0f",d)+"°"+String.format("%.0f",m)+"`"+String.format("%.0f",s)+ "";

        return result;
    }
    //Прямая геодезическая задача
    static String AheadTask(double Xa1, double Ya1, double D1, double degree)
    {
        double dX1 = 0.0;
        if (degree<90) {
            dX1 = D1 * Math.cos(Math.toRadians(degree));
        }
        else if (degree>=90 && degree<180) {
            dX1 = -(D1 * Math.cos(Math.toRadians((180-degree))));
        }
        else if (degree>=180 && degree<270) {
            dX1 = -(D1 * Math.cos(Math.toRadians((degree-180))));
        }
        else if (degree>=270 && degree<360) {
            dX1 = D1 * Math.cos(Math.toRadians((360-degree)));
        }
        double Xb1 = Xa1 + dX1;

        double dY1 = 0.0;
        if (degree<90) {
            dY1 = D1 * Math.sin(Math.toRadians(degree));
        }
        else if (degree>=90 && degree<180) {
            dY1 = D1 * Math.sin(Math.toRadians((180-degree)));
        }
        else if (degree>=180 && degree<270) {
            dY1 = -(D1 * Math.sin(Math.toRadians((degree-180))));
        }
        else if (degree>=270 && degree<360) {
            dY1 = -(D1 * Math.sin(Math.toRadians((360-degree))));
        }
        double Yb1= Ya1 + dY1;

        String h = String.format("%.2f",Xb1) + " " + String.format("%.2f",Yb1);
        return h;
    }

    //Обратная геодезическая задача
    static String InverseTask(double Xa2, double Ya2, double Xb2, double Yb2)
    {
        double dX2 = Xb2 - Xa2;
        double dY2 = Yb2 - Ya2;
        double r = 180/Math.PI * Math.abs(Math.atan(dY2/dX2));
        double alfa = 0;
        if (dX2 > 0 && dY2 > 0) {
            alfa = r;
        }
        if (dX2 < 0 && dY2 > 0) {
            alfa = 180 - r;
        }
        if (dX2 < 0 && dY2 < 0) {
            alfa = r - 180;
        }

        if (dX2 > 0 && dY2 < 0) {
            alfa = 360- r;
        }
        double d1 = dX2/Math.cos(Math.toRadians(alfa));
        double d2 = dY2/Math.sin(Math.toRadians(alfa));
        double D = Math.sqrt(dX2*dX2+dY2*dY2);
        String l = String.format("%.2f",D) + " " + Double.toString(dX2) + " " + Double.toString(dY2) + " " + Double.toString(r) + " " + Double.toString(alfa);
        return l;
    }
}
