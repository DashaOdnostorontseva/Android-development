package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class activity_inverse_Task extends AppCompatActivity {

    TextView tr1, tr3, tr4, tr5, tr6;
    EditText it1, it2, it3, tr2;
    Button button2, iV1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inverse_task);
        tr1 = findViewById(R.id.tr1);
        tr3 = findViewById(R.id.tr3);
        tr4 = findViewById(R.id.tr4);
        tr5 = findViewById(R.id.tr5);
        tr6 = findViewById(R.id.tr6);
        it1 = findViewById(R.id.it1);
        it2 = findViewById(R.id.it2);
        it3 = findViewById(R.id.it3);
        tr2 = findViewById(R.id.tr2);
        button2 = findViewById(R.id.tr11);
        iV1 = findViewById(R.id.iV1);



        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    Double Xa2 = Double.parseDouble(it1.getText().toString());
                    Double Ya2 = Double.parseDouble(it2.getText().toString());
                    Double Xb2 = Double.parseDouble(it3.getText().toString());
                    Double Yb2 = Double.parseDouble(tr2.getText().toString());
                    String l = geo_calc.InverseTask(Xa2, Ya2, Xb2, Yb2);
                    String[] a = l.split(" ");
                    tr1.setText(String.valueOf(a[0]));
                    tr3.setText(String.valueOf(a[1]));
                    tr4.setText(String.valueOf(a[2]));
                    tr5.setText(String.valueOf(a[3]));
                    tr6.setText(String.valueOf(a[4]));

                }
                catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(),"Ошибка", Toast.LENGTH_SHORT).show();;
                }
            }
        } );
        iV1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_inverse_task = "dX = " + tr1.getText().toString() + " dY = " + tr3.getText().toString() + " r = " +tr4.getText().toString() + " Alfa = " + tr5.getText().toString() + " D = " + tr6.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_inverse_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"Скопированы все данные", Toast.LENGTH_SHORT).show();
                it1.setText("");
                it2.setText("");
                it3.setText("");
                tr2.setText("");
            }
        });

        tr3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_ahed_task = tr3.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_ahed_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"dX скопировано", Toast.LENGTH_SHORT).show();
                it1.setText("");
                it2.setText("");
                it3.setText("");
                tr2.setText("");
            }
        });

        tr4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_ahed_task = tr4.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_ahed_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"dY скопировано", Toast.LENGTH_SHORT).show();
                it1.setText("");
                it2.setText("");
                it3.setText("");
                tr2.setText("");
            }
        });

        tr5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_ahed_task = tr5.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_ahed_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"r скопировано", Toast.LENGTH_SHORT).show();
                it1.setText("");
                it2.setText("");
                it3.setText("");
                tr2.setText("");
            }
        });

        tr6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_ahed_task = tr6.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_ahed_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"Alfa скопировано", Toast.LENGTH_SHORT).show();
                it1.setText("");
                it2.setText("");
                it3.setText("");
                tr2.setText("");
            }
        });

        tr1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_ahed_task = tr1.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_ahed_task);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"D скопировано", Toast.LENGTH_SHORT).show();
                it1.setText("");
                it2.setText("");
                it3.setText("");
                tr2.setText("");
            }
        });
    }
    public void menu(View view) {
        Intent menu = new Intent(this, MainActivity.class);
        startActivity(menu);
    }
    public void browser(View view5) {

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.miigaik.ru/"));
        startActivity(browserIntent);
    }
    public void vk(View view6) {

        Intent vkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://vk.com/daria_cross/"));
        startActivity(vkIntent);
    }
}