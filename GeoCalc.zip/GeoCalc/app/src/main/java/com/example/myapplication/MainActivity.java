package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void to_degree(View view1) {
        Intent to_degree = new Intent(this, activity_to_degree.class);
        startActivity(to_degree);
    }

    public void to_revert(View view2) {
        Intent to_revert = new Intent(this, activity_to_revert.class);
        startActivity(to_revert);
    }

    public void ahead_task(View view3) {
        Intent ahead_task = new Intent(this, acivity_ahead_Task.class);
        startActivity(ahead_task);
    }

    public void inverse_task(View view4) {
        Intent inverse_task = new Intent(this, activity_inverse_Task.class);
        startActivity(inverse_task);
    }

    public void browser(View view5) {

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.miigaik.ru/"));
        startActivity(browserIntent);
        }

    public void vk(View view6) {

        Intent vkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://vk.com/daria_cross/"));
        startActivity(vkIntent);
    }
}
