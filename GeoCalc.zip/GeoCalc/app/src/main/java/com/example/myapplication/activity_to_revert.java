package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class activity_to_revert extends AppCompatActivity {
    TextView tr1;
    EditText tr2;
    Button tr3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_revert);
        tr1 = findViewById(R.id.tr1);
        tr2 = findViewById(R.id.tr2);
        tr3 = findViewById(R.id.tr11);

        tr3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Double d = Double.parseDouble(tr2.getText().toString());

                    String degree = geo_calc.toRevert(d);
                    tr1.setText(String.valueOf(degree));
                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), "Ошибка", Toast.LENGTH_SHORT).show();
                    ;
                }
            }
        } );
        tr1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String Value_to_revert = tr1.getText().toString(); // Сохраняем выведенный ответ в переменную Value
                ClipboardManager Clip = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Data", Value_to_revert);
                Clip.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"Скопировано", Toast.LENGTH_SHORT).show();
                tr2.setText("");
            }
        });
    }
    public void menu(View view)
    {
        Intent menu = new Intent(this, MainActivity.class);
        startActivity(menu);
    }
    public void browser(View view5) {

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.miigaik.ru/"));
        startActivity(browserIntent);
    }
    public void vk(View view6) {

        Intent vkIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://vk.com/daria_cross/"));
        startActivity(vkIntent);
    }
}